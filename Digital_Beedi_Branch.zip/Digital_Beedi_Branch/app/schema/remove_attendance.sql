-- Remove attendance table and its references
DROP TABLE IF EXISTS attendance;